# SimuladorPOS - Documentação do Projeto

## Visão Geral
Simulador de terminal POS (Point of Sale) desenvolvido em **WPF .NET 8** para desktop Windows.
Simula operações de pagamento com interface visual moderna no estilo de um terminal físico.

---

## Funcionalidades Implementadas

- [x] Teclado numérico para digitação de valor (centavos, tipo terminal real)
- [x] Seleção de forma de pagamento: **PIX**, **Débito**, **Crédito**
- [x] Seleção de cartão pré-cadastrado (hardcode) para débito/crédito
- [x] Seleção de parcelas (1x a 12x) para crédito
- [x] Geração de QR Code PIX a partir de string hardcoded
- [x] Simulação de processamento (2s de loading)
- [x] Comprovante (slip) gerado com dados hardcoded + dados da transação
- [x] Relógio em tempo real no header
- [x] Botão "Nova Transação" para reiniciar o fluxo

---

## Estrutura do Projeto

```
SimuladorPOS/
├── Models/
│   ├── Card.cs              - Modelo de cartão (débito/crédito)
│   └── PaymentData.cs       - Enum PaymentMethod, PaymentScreen, HardcodedData
├── ViewModels/
│   ├── BaseViewModel.cs     - INotifyPropertyChanged + RelayCommand
│   └── MainViewModel.cs     - ViewModel principal com toda a lógica
├── Converters/
│   └── Converters.cs        - BoolToVisibility, EqualityToVisibility, EqualityToBool
├── MainWindow.xaml          - UI principal (única janela, telas por Visibility)
├── MainWindow.xaml.cs       - Code-behind (relógio)
├── App.xaml                 - Application entry point
└── SimuladorPOS.csproj      - Projeto WPF net8.0-windows
```

---

## Fluxo de Telas

```
[AmountScreen]
  → Digitar valor no numpad
  → Selecionar PIX / Débito / Crédito
  → Botão AVANÇAR

     ↓ PIX                        ↓ Débito/Crédito
[PixQrCode]                    [CardSelection]
  → QR Code gerado                → Lista de cartões hardcoded
  → "Confirmar pagamento ✓"       → Parcelas (só crédito)
                                  → Hint de aviso enquanto sem cartão selecionado
                                  → Botão "PAGAR ✓" aparece após selecionar

          ↓ (ambos levam a)
       [Processing]
          → Spinner animado (2,5s)
          → Mostra cartão ou PIX sendo processado

          ↓
       [Slip / Comprovante]
          → Banner verde de aprovação
          → Papel branco com comprovante detalhado
          → Nova Transação → [AmountScreen]
```

---

## Dados Hardcoded

### Cartões de Débito
| ID | Portador | Bandeira | Final |
|----|----------|----------|-------|
| D1 | JOÃO DA SILVA | VISA | 5678 |
| D2 | MARIA SOUZA | MASTERCARD | 3412 |
| D3 | PEDRO COSTA | ELO | 9001 |

### Cartões de Crédito
| ID | Portador | Bandeira | Final |
|----|----------|----------|-------|
| C1 | JOÃO DA SILVA | VISA | 1234 |
| C2 | MARIA SOUZA | MASTERCARD | 5678 |
| C3 | ANA LIMA | AMEX | 4321 |
| C4 | CARLOS FERREIRA | HIPERCARD | 8765 |

### PIX QR Code Payload
String EMV padrão Banco Central do Brasil (hardcoded em `HardcodedData.PixQrCodePayload`)

### Comprovante (Slip)
Template em `HardcodedData.ReceiptSlip` com placeholders:
- `{DATETIME}` - data/hora da transação
- `{NSU}` - número sequencial único gerado
- `{AUTH}` - código de autorização aleatório
- `{METHOD}` - forma de pagamento
- `{CARD_INFO}` - dados do cartão (se aplicável)
- `{AMOUNT}` - valor formatado em reais

---

## Dependências NuGet

| Pacote | Versão | Uso |
|--------|--------|-----|
| QRCoder | 1.6.0 | Geração do QR Code PIX |
| Microsoft.Xaml.Behaviors.Wpf | 1.1.142 | Behaviors WPF |

---

## Como Executar

```powershell
cd SimuladorPOS
dotnet run
```

Ou compilar para executável:
```powershell
dotnet publish -c Release -r win-x64 --self-contained true
```

---

## Arquitetura

- **Padrão MVVM** (Model-View-ViewModel)
- Uma única `MainWindow` com múltiplos painéis controlados por `Visibility`
- `EqualityToVisibilityConverter` controla qual painel é exibido com base em `CurrentScreen` (enum)
- `RelayCommand` implementado localmente (sem dependência de framework MVVM externo)
- `BitmapImage` gerada em memória pelo QRCoder e exibida via binding

---

## Raciocínio de Design

- **Teclado numérico tipo POS**: entrada sempre em centavos (como terminais reais), sem vírgula manual
- **Uma janela, múltiplos painéis**: mais simples que navegação entre Pages/Windows, mantém estado
- **Visually disabled ConfirmButton**: `CanConfirm()` bloqueia confirmação se cartão não selecionado
- **2s delay async**: simula comunicação com adquirente
- **Cores**: paleta escura inspirada em terminais modernos (#1A1A2E base, #E94560 accent)
