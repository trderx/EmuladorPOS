# 🏪 Simulador POS — Documentação do Projeto

**Versão:** 1.0  
**Plataforma:** .NET 8 · WPF · Windows Desktop  
**Banco de Dados:** SQLite (via Entity Framework Core 8)  
**Padrão de Arquitetura:** MVVM  
**Data de criação:** 15/03/2026

---

## 📋 Visão Geral

Aplicação desktop de **Ponto de Venda (PDV)** simulando o fluxo completo de uma operação de caixa: seleção de produtos, montagem do carrinho, processamento de pagamento e relatórios de vendas. Interface moderna com tema escuro.

---

## 🗂️ Estrutura do Projeto

```
SimuladorPOS/
├── SimuladorPOS.sln                  # Arquivo de solução
└── SimuladorPOS/
    ├── App.xaml / App.xaml.cs        # Ponto de entrada + inicialização do BD
    ├── MainWindow.xaml / .cs         # Janela principal com navegação
    │
    ├── Models/                       # Modelos de domínio
    │   ├── Produto.cs                # Entidade produto
    │   ├── Venda.cs                  # Entidade venda + enums (Status, FormaPagamento)
    │   ├── ItemVenda.cs              # Linha de item de uma venda salva
    │   └── ItemCarrinho.cs           # Item no carrinho (ObservableObject)
    │
    ├── Data/                         # Acesso a dados (EF Core)
    │   ├── AppDbContext.cs           # DbContext SQLite
    │   └── SeedData.cs               # 20 produtos pré-cadastrados
    │
    ├── Services/                     # Lógica de negócio
    │   ├── ProdutoService.cs         # CRUD de produtos, filtro, busca por código
    │   └── VendaService.cs           # Finalização de vendas, histórico, resumo
    │
    ├── ViewModels/                   # MVVM ViewModels
    │   ├── BaseViewModel.cs          # INotifyPropertyChanged base
    │   ├── RelayCommand.cs           # ICommand síncrono e assíncrono + genérico
    │   ├── MainViewModel.cs          # ViewModel da janela principal + relógio
    │   ├── PDVViewModel.cs           # ViewModel do PDV (carrinho, produtos)
    │   ├── PagamentoViewModel.cs     # ViewModel da tela de pagamento
    │   └── RelatorioViewModel.cs     # ViewModel de relatórios
    │
    ├── Views/                        # Interface gráfica (WPF)
    │   ├── PDVView.xaml / .cs        # Tela principal do PDV
    │   ├── PagamentoWindow.xaml/.cs  # Modal de pagamento com numpad
    │   └── RelatorioView.xaml / .cs  # Tela de relatórios e histórico
    │
    └── Helpers/
        └── Converters.cs             # IValueConverters para bindings XAML
```

---

## ⚙️ Funcionalidades Implementadas

### 🖥️ Tela PDV (Ponto de Venda)
- [x] Grade de produtos com emoji, nome, preço
- [x] Filtro por texto (nome/código) em tempo real
- [x] Filtro por categoria (chips de navegação horizontal)
- [x] Adicionar produto ao carrinho com um clique
- [x] Controle de quantidade (+ / −) por item
- [x] Remover item do carrinho
- [x] Limpar carrinho completo (com confirmação)
- [x] Campo de desconto na venda
- [x] Cálculo automático de subtotal, desconto e total
- [x] Contador de itens no carrinho
- [x] Estado vazio com mensagem amigável
- [x] Status bar com mensagem de feedback

### 💳 Tela de Pagamento (Modal)
- [x] Seleção de forma: Dinheiro, Crédito, Débito, PIX, Voucher
- [x] Numpad virtual para entrada de valor (dinheiro)
- [x] Cálculo automático de troco
- [x] Validação: só confirma se valor ≥ total
- [x] Exibição de total e troco em destaque
- [x] Painel digital para pagamentos não-dinheiro

### 📊 Tela de Relatórios
- [x] Filtro por período (data início e fim)
- [x] Atalhos: Hoje, 7 dias, Mês atual
- [x] Cards de resumo: Total de vendas, Valor total, Ticket médio, Dinheiro, Cartão/PIX
- [x] Lista de vendas com número, data/hora, forma, total
- [x] Detalhe da venda selecionada (itens, subtotais, troco)

### 🏗️ Infraestrutura
- [x] Banco SQLite local (`%LOCALAPPDATA%/SimuladorPOS/pos.db`)
- [x] Migrations automáticas com `EnsureCreated`
- [x] 20 produtos pré-cadastrados com seed data
- [x] Atualização automática de estoque ao finalizar venda
- [x] Geração de número de venda único (PDV-YYYYMMDD-XXXX)
- [x] Relógio em tempo real na barra superior

---

## 🎨 Design e UI

- **Tema:** Dark Mode (#1A1D23 base)
- **Acento primário:** Verde #00C878
- **Acento secundário:** Azul #5B8CFF, Laranja #FFB347
- **Fonte:** Segoe UI
- **Resolução mínima:** 1100 x 700

---

## 📦 Pacotes NuGet

| Pacote | Versão | Uso |
|--------|--------|-----|
| CommunityToolkit.Mvvm | 8.4.0 | ObservableObject para ItemCarrinho |
| Microsoft.EntityFrameworkCore.Sqlite | 8.0.0 | Persistência SQLite |
| Microsoft.EntityFrameworkCore.Design | 8.0.0 | Ferramentas EF |

---

## 🚀 Como Executar

```bash
cd SimuladorPOS
dotnet run
```

Ou abrir `SimuladorPOS.sln` no Visual Studio 2022+ e pressionar F5.

---

## 🔄 Fluxo de Uso

```
1. Iniciar aplicativo
   └─→ Banco de dados é criado/inicializado automaticamente

2. Tela PDV
   ├─→ Buscar/filtrar produtos
   ├─→ Clicar em produto → adiciona ao carrinho
   ├─→ Ajustar quantidades no carrinho
   ├─→ Aplicar desconto (opcional)
   └─→ Clicar "FINALIZAR VENDA"

3. Tela de Pagamento (Modal)
   ├─→ Selecionar forma de pagamento
   ├─→ Informar valor pago (dinheiro) ou confirmar direto
   └─→ Clicar "CONFIRMAR PAGAMENTO"

4. Venda salva → estoque atualizado → carrinho limpo

5. Tela Relatórios
   ├─→ Filtrar por período
   └─→ Visualizar resumo e detalhes das vendas
```

---

## 📝 Decisões de Arquitetura

- **MVVM sem framework pesado** (exceto CommunityToolkit apenas para `ObservableObject`): mantém leveza e controle
- **RelayCommand próprio** com variante async: evita dependências extras
- **SQLite** para portabilidade total (banco embutido, sem servidor)
- **EnsureCreated** no startup: garante que o banco seja criado na primeira execução
- **DataTemplate automático**: o `ContentControl` da `MainWindow` resolve a View correta pelo tipo do ViewModel

---

## 🔮 Melhorias Futuras Possíveis

- [ ] Cadastro/edição de produtos na interface
- [ ] Cancelamento de venda
- [ ] Impressão de cupom fiscal simulado
- [ ] Múltiplos operadores/caixa
- [ ] Gráficos de vendas (ChartControl)
- [ ] Exportação de relatório em PDF/Excel
- [ ] Código de barras (scanner USB)
- [ ] Desconto por item individualmente
- [ ] Controle de caixa (abertura/fechamento)
