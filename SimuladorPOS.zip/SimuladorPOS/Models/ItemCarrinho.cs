using CommunityToolkit.Mvvm.ComponentModel;

namespace SimuladorPOS.Models;

public partial class ItemCarrinho : ObservableObject
{
    public Produto Produto { get; set; } = null!;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(Subtotal))]
    private int _quantidade = 1;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(Subtotal))]
    private decimal _desconto;

    public decimal PrecoUnitario => Produto?.Preco ?? 0;
    public decimal Subtotal => (PrecoUnitario * Quantidade) - Desconto;
    public string NomeProduto => Produto?.Nome ?? string.Empty;
}
