namespace SimuladorPOS.Models
{
    public enum CardType { Debit, Credit }

    public class Card
    {
        public string Id { get; set; } = string.Empty;
        public string HolderName { get; set; } = string.Empty;
        public string MaskedNumber { get; set; } = string.Empty;
        public string Brand { get; set; } = string.Empty;
        public CardType Type { get; set; }

        public string DisplayName => $"{Brand} •••• {MaskedNumber[^4..]} - {HolderName}";
    }
}
