using System.ComponentModel.DataAnnotations;

namespace SimuladorPOS.Models;

public class Produto
{
    [Key]
    public int Id { get; set; }

    [Required]
    [MaxLength(100)]
    public string Nome { get; set; } = string.Empty;

    [MaxLength(20)]
    public string Codigo { get; set; } = string.Empty;

    [MaxLength(50)]
    public string Categoria { get; set; } = string.Empty;

    public decimal Preco { get; set; }

    public int Estoque { get; set; }

    [MaxLength(200)]
    public string Descricao { get; set; } = string.Empty;

    public bool Ativo { get; set; } = true;

    public string EmojiIcone { get; set; } = "🛒";
}
