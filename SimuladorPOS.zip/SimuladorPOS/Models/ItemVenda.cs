using System.ComponentModel.DataAnnotations;

namespace SimuladorPOS.Models;

public class ItemVenda
{
    [Key]
    public int Id { get; set; }

    public int VendaId { get; set; }
    public Venda? Venda { get; set; }

    public int ProdutoId { get; set; }
    public Produto? Produto { get; set; }

    public string NomeProduto { get; set; } = string.Empty;
    public decimal PrecoUnitario { get; set; }
    public int Quantidade { get; set; }
    public decimal Desconto { get; set; }

    public decimal Subtotal => (PrecoUnitario * Quantidade) - Desconto;
}
