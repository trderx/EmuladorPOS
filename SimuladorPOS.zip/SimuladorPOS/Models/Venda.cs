using System.ComponentModel.DataAnnotations;

namespace SimuladorPOS.Models;

public enum StatusVenda
{
    Aberta,
    Finalizada,
    Cancelada
}

public enum FormaPagamento
{
    Dinheiro,
    CartaoCredito,
    CartaoDebito,
    PIX,
    Voucher
}

public class Venda
{
    [Key]
    public int Id { get; set; }

    public string NumeroVenda { get; set; } = string.Empty;
    public DateTime DataHora { get; set; } = DateTime.Now;
    public StatusVenda Status { get; set; } = StatusVenda.Aberta;
    public FormaPagamento FormaPagamento { get; set; }

    public decimal Subtotal { get; set; }
    public decimal Desconto { get; set; }
    public decimal Total { get; set; }
    public decimal ValorPago { get; set; }
    public decimal Troco { get; set; }

    public string? NomeOperador { get; set; }
    public string? Observacao { get; set; }

    public List<ItemVenda> Itens { get; set; } = new();
}
