namespace SimuladorPOS.Models
{
    public enum PaymentMethod { Pix, Debit, Credit }
    public enum PaymentScreen { Amount, CardSelection, PixQrCode, Processing, Slip }

    public class PaymentData
    {
        public decimal Amount { get; set; }
        public PaymentMethod Method { get; set; }
        public Card? SelectedCard { get; set; }
        public int Installments { get; set; } = 1;
    }

    public static class HardcodedData
    {
        public static readonly string PixQrCodePayload =
            "00020126580014br.gov.bcb.pix0136a629534e-7693-4846-852d-1bbff817b5a8" +
            "5204000053039865406100.005802BR5913LOJA EXEMPLO6009SAO PAULO62070503***" +
            "6304E2CA";

        public static readonly string ReceiptSlip =
            "================================================\n" +
            "            SIMULADOR POS - COMPROVANTE         \n" +
            "================================================\n" +
            "ESTABELECIMENTO: LOJA DEMONSTRAÇÃO LTDA         \n" +
            "CNPJ: 00.000.000/0001-00                        \n" +
            "ENDEREÇO: Rua Exemplo, 123 - São Paulo/SP       \n" +
            "------------------------------------------------\n" +
            "DATA/HORA: {DATETIME}                           \n" +
            "NSU: {NSU}                                      \n" +
            "AUTORIZACAO: {AUTH}                             \n" +
            "------------------------------------------------\n" +
            "FORMA DE PAGAMENTO: {METHOD}                    \n" +
            "{CARD_INFO}" +
            "VALOR: R$ {AMOUNT}                              \n" +
            "================================================\n" +
            "        TRANSACAO AUTORIZADA COM SUCESSO        \n" +
            "================================================\n" +
            "   VIA DO CLIENTE - GUARDE ESTE COMPROVANTE     \n" +
            "================================================";

        public static readonly List<Card> DebitCards = new()
        {
            new Card { Id = "D1", HolderName = "JOÃO DA SILVA", MaskedNumber = "5678", Brand = "VISA", Type = CardType.Debit },
            new Card { Id = "D2", HolderName = "MARIA SOUZA", MaskedNumber = "3412", Brand = "MASTERCARD", Type = CardType.Debit },
            new Card { Id = "D3", HolderName = "PEDRO COSTA", MaskedNumber = "9001", Brand = "ELO", Type = CardType.Debit },
        };

        public static readonly List<Card> CreditCards = new()
        {
            new Card { Id = "C1", HolderName = "JOÃO DA SILVA", MaskedNumber = "1234", Brand = "VISA", Type = CardType.Credit },
            new Card { Id = "C2", HolderName = "MARIA SOUZA", MaskedNumber = "5678", Brand = "MASTERCARD", Type = CardType.Credit },
            new Card { Id = "C3", HolderName = "ANA LIMA", MaskedNumber = "4321", Brand = "AMEX", Type = CardType.Credit },
            new Card { Id = "C4", HolderName = "CARLOS FERREIRA", MaskedNumber = "8765", Brand = "HIPERCARD", Type = CardType.Credit },
        };
    }
}
