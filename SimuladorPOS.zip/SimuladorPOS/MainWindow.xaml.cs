using System.Windows;
using SimuladorPOS.ViewModels;

namespace SimuladorPOS;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();
    }
}
