using SimuladorPOS.Models;

namespace SimuladorPOS.Data;

public static class SeedData
{
    public static Produto[] GetProdutos() =>
    [
        new() { Id = 1, Nome = "Coca-Cola 350ml", Codigo = "7891000315507", Categoria = "Bebidas", Preco = 5.50m, Estoque = 100, EmojiIcone = "🥤" },
        new() { Id = 2, Nome = "Água Mineral 500ml", Codigo = "7896069900027", Categoria = "Bebidas", Preco = 2.50m, Estoque = 150, EmojiIcone = "💧" },
        new() { Id = 3, Nome = "Suco de Laranja 1L", Codigo = "7896069901024", Categoria = "Bebidas", Preco = 8.90m, Estoque = 60, EmojiIcone = "🍊" },
        new() { Id = 4, Nome = "Cerveja Lata 350ml", Codigo = "7891149107024", Categoria = "Bebidas", Preco = 4.50m, Estoque = 200, EmojiIcone = "🍺" },
        new() { Id = 5, Nome = "Pão Francês (un)", Codigo = "7890000100015", Categoria = "Padaria", Preco = 0.80m, Estoque = 500, EmojiIcone = "🍞" },
        new() { Id = 6, Nome = "Croissant", Codigo = "7890000100022", Categoria = "Padaria", Preco = 4.50m, Estoque = 50, EmojiIcone = "🥐" },
        new() { Id = 7, Nome = "Bolo de Chocolate", Codigo = "7890000100039", Categoria = "Padaria", Preco = 18.00m, Estoque = 20, EmojiIcone = "🎂" },
        new() { Id = 8, Nome = "Café Expresso", Codigo = "7890000200011", Categoria = "Cafeteria", Preco = 5.00m, Estoque = 999, EmojiIcone = "☕" },
        new() { Id = 9, Nome = "Cappuccino", Codigo = "7890000200028", Categoria = "Cafeteria", Preco = 8.00m, Estoque = 999, EmojiIcone = "☕" },
        new() { Id = 10, Nome = "Chá Gelado", Codigo = "7890000200035", Categoria = "Cafeteria", Preco = 6.00m, Estoque = 80, EmojiIcone = "🧋" },
        new() { Id = 11, Nome = "Hambúrguer Artesanal", Codigo = "7890000300017", Categoria = "Lanches", Preco = 25.00m, Estoque = 40, EmojiIcone = "🍔" },
        new() { Id = 12, Nome = "Batata Frita P", Codigo = "7890000300024", Categoria = "Lanches", Preco = 10.00m, Estoque = 60, EmojiIcone = "🍟" },
        new() { Id = 13, Nome = "Pizza Margherita", Codigo = "7890000300031", Categoria = "Lanches", Preco = 45.00m, Estoque = 30, EmojiIcone = "🍕" },
        new() { Id = 14, Nome = "Sorvete Bola", Codigo = "7890000400010", Categoria = "Sobremesas", Preco = 7.00m, Estoque = 100, EmojiIcone = "🍦" },
        new() { Id = 15, Nome = "Brownie", Codigo = "7890000400027", Categoria = "Sobremesas", Preco = 9.00m, Estoque = 50, EmojiIcone = "🍫" },
        new() { Id = 16, Nome = "Açaí 300ml", Codigo = "7890000400034", Categoria = "Sobremesas", Preco = 16.00m, Estoque = 40, EmojiIcone = "🫐" },
        new() { Id = 17, Nome = "Chips Batata 50g", Codigo = "7890000500013", Categoria = "Snacks", Preco = 5.00m, Estoque = 80, EmojiIcone = "🥔" },
        new() { Id = 18, Nome = "Barra de Cereal", Codigo = "7890000500020", Categoria = "Snacks", Preco = 3.50m, Estoque = 100, EmojiIcone = "🌾" },
        new() { Id = 19, Nome = "Iogurte Natural", Codigo = "7890000600016", Categoria = "Laticínios", Preco = 4.50m, Estoque = 70, EmojiIcone = "🥛" },
        new() { Id = 20, Nome = "Queijo Mussarela 200g", Codigo = "7890000600023", Categoria = "Laticínios", Preco = 12.00m, Estoque = 50, EmojiIcone = "🧀" },
    ];
}
