using System.Windows.Input;
using SimuladorPOS.Models;

namespace SimuladorPOS.ViewModels;

public class PagamentoViewModel : BaseViewModel
{
    private FormaPagamento _formaSelecionada = FormaPagamento.Dinheiro;
    private decimal _valorPago;
    private string _valorPagoTexto = string.Empty;

    public decimal TotalVenda { get; }
    public decimal DescontoVenda { get; }

    public FormaPagamento FormaSelecionada
    {
        get => _formaSelecionada;
        set
        {
            SetProperty(ref _formaSelecionada, value);
            if (value != FormaPagamento.Dinheiro)
                ValorPago = TotalVenda;
            OnPropertyChanged(nameof(IsDinheiro));
            OnPropertyChanged(nameof(Troco));
            OnPropertyChanged(nameof(TrocoFormatado));
            OnPropertyChanged(nameof(PodeFinalizar));
        }
    }

    public decimal ValorPago
    {
        get => _valorPago;
        set
        {
            SetProperty(ref _valorPago, value);
            _valorPagoTexto = value.ToString("F2");
            OnPropertyChanged(nameof(ValorPagoTexto));
            OnPropertyChanged(nameof(Troco));
            OnPropertyChanged(nameof(TrocoFormatado));
            OnPropertyChanged(nameof(PodeFinalizar));
        }
    }

    public string ValorPagoTexto
    {
        get => _valorPagoTexto;
        set
        {
            _valorPagoTexto = value;
            if (decimal.TryParse(value.Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var v))
                _valorPago = v;
            OnPropertyChanged(nameof(Troco));
            OnPropertyChanged(nameof(TrocoFormatado));
            OnPropertyChanged(nameof(PodeFinalizar));
        }
    }

    public bool IsDinheiro => FormaSelecionada == FormaPagamento.Dinheiro;
    public decimal Troco => Math.Max(0, ValorPago - TotalVenda);
    public string TrocoFormatado => Troco.ToString("C2");
    public string TotalFormatado => TotalVenda.ToString("C2");
    public bool PodeFinalizar => ValorPago >= TotalVenda;

    public bool Confirmado { get; private set; }

    public ICommand SelecionarFormaCommand { get; }
    public ICommand AdicionarValorCommand { get; }
    public ICommand LimparValorCommand { get; }
    public ICommand ConfirmarCommand { get; }
    public ICommand CancelarCommand { get; }

    public event Action? Confirmar;
    public event Action? Cancelar;

    public PagamentoViewModel(decimal total, decimal desconto)
    {
        TotalVenda = total;
        DescontoVenda = desconto;
        ValorPago = total;

        SelecionarFormaCommand = new RelayCommand<string>(SelecionarForma);
        AdicionarValorCommand = new RelayCommand<string>(AdicionarValor);
        LimparValorCommand = new RelayCommand(LimparValor);
        ConfirmarCommand = new RelayCommand(ExecutarConfirmar, () => PodeFinalizar);
        CancelarCommand = new RelayCommand(() => Cancelar?.Invoke());
    }

    private void SelecionarForma(string? forma)
    {
        FormaSelecionada = forma switch
        {
            "Dinheiro" => FormaPagamento.Dinheiro,
            "CartaoCredito" => FormaPagamento.CartaoCredito,
            "CartaoDebito" => FormaPagamento.CartaoDebito,
            "PIX" => FormaPagamento.PIX,
            "Voucher" => FormaPagamento.Voucher,
            _ => FormaPagamento.Dinheiro
        };
    }

    private void AdicionarValor(string? valor)
    {
        if (valor == "C")
        {
            LimparValor();
            return;
        }
        if (valor == "." && _valorPagoTexto.Contains('.')) return;

        var novoTexto = _valorPagoTexto == "0" && valor != "." ? valor : _valorPagoTexto + valor;
        ValorPagoTexto = novoTexto ?? "0";
    }

    private void LimparValor()
    {
        ValorPago = 0;
        ValorPagoTexto = "0";
    }

    private void ExecutarConfirmar()
    {
        Confirmado = true;
        Confirmar?.Invoke();
    }
}
