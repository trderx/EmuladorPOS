using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using SimuladorPOS.Models;
using SimuladorPOS.Services;

namespace SimuladorPOS.ViewModels;

public class PDVViewModel : BaseViewModel
{
    private readonly ProdutoService _produtoService;
    private readonly VendaService _vendaService;

    private string _filtro = string.Empty;
    private string _categoriaFiltro = string.Empty;
    private ItemCarrinho? _itemSelecionado;
    private decimal _descontoVenda;
    private bool _isLoading;
    private string _statusMessage = "Pronto";

    public ObservableCollection<Produto> Produtos { get; } = new();
    public ObservableCollection<ItemCarrinho> Carrinho { get; } = new();
    public ObservableCollection<string> Categorias { get; } = new();

    public string Filtro
    {
        get => _filtro;
        set { SetProperty(ref _filtro, value); _ = CarregarProdutosAsync(); }
    }

    public string CategoriaFiltro
    {
        get => _categoriaFiltro;
        set { SetProperty(ref _categoriaFiltro, value); _ = CarregarProdutosAsync(); }
    }

    public ItemCarrinho? ItemSelecionado
    {
        get => _itemSelecionado;
        set => SetProperty(ref _itemSelecionado, value);
    }

    public decimal DescontoVenda
    {
        get => _descontoVenda;
        set { SetProperty(ref _descontoVenda, value); OnPropertyChanged(nameof(Total)); OnPropertyChanged(nameof(TotalFormatado)); }
    }

    public bool IsLoading
    {
        get => _isLoading;
        set => SetProperty(ref _isLoading, value);
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetProperty(ref _statusMessage, value);
    }

    public decimal Subtotal => Carrinho.Sum(i => i.Subtotal);
    public decimal Total => Math.Max(0, Subtotal - DescontoVenda);
    public int TotalItens => Carrinho.Sum(i => i.Quantidade);
    public string TotalFormatado => Total.ToString("C2");
    public string SubtotalFormatado => Subtotal.ToString("C2");
    public bool CarrinhoVazio => !Carrinho.Any();

    public ICommand AdicionarProdutoCommand { get; }
    public ICommand RemoverItemCommand { get; }
    public ICommand AumentarQtdCommand { get; }
    public ICommand DiminuirQtdCommand { get; }
    public ICommand LimparCarrinhoCommand { get; }
    public ICommand AbrirPagamentoCommand { get; }
    public ICommand FiltrarCategoriaCommand { get; }

    public event Action<PDVViewModel>? SolicitarPagamento;

    public PDVViewModel()
    {
        _produtoService = new ProdutoService();
        _vendaService = new VendaService(_produtoService);

        AdicionarProdutoCommand = new RelayCommand<Produto>(AdicionarProduto);
        RemoverItemCommand = new RelayCommand<ItemCarrinho>(RemoverItem);
        AumentarQtdCommand = new RelayCommand<ItemCarrinho>(AumentarQtd);
        DiminuirQtdCommand = new RelayCommand<ItemCarrinho>(DiminuirQtd);
        LimparCarrinhoCommand = new RelayCommand(LimparCarrinho, () => !CarrinhoVazio);
        AbrirPagamentoCommand = new RelayCommand(AbrirPagamento, () => !CarrinhoVazio);
        FiltrarCategoriaCommand = new RelayCommand<string>(cat => CategoriaFiltro = cat ?? string.Empty);

        _ = InicializarAsync();
    }

    private async Task InicializarAsync()
    {
        await CarregarCategoriasAsync();
        await CarregarProdutosAsync();
    }

    private async Task CarregarCategoriasAsync()
    {
        var cats = await _produtoService.ObterCategoriasAsync();
        Application.Current.Dispatcher.Invoke(() =>
        {
            Categorias.Clear();
            Categorias.Add("Todos");
            foreach (var cat in cats)
                Categorias.Add(cat);
        });
    }

    public async Task CarregarProdutosAsync()
    {
        IsLoading = true;
        var cat = CategoriaFiltro == "Todos" ? null : CategoriaFiltro;
        var lista = await _produtoService.ObterTodosAsync(Filtro, cat);
        Application.Current.Dispatcher.Invoke(() =>
        {
            Produtos.Clear();
            foreach (var p in lista)
                Produtos.Add(p);
        });
        IsLoading = false;
    }

    private void AdicionarProduto(Produto? produto)
    {
        if (produto == null) return;

        var existente = Carrinho.FirstOrDefault(i => i.Produto.Id == produto.Id);
        if (existente != null)
        {
            existente.Quantidade++;
        }
        else
        {
            var item = new ItemCarrinho { Produto = produto };
            item.PropertyChanged += (_, _) => AtualizarTotais();
            Carrinho.Add(item);
        }

        AtualizarTotais();
        StatusMessage = $"✓ {produto.Nome} adicionado";
    }

    private void RemoverItem(ItemCarrinho? item)
    {
        if (item == null) return;
        Carrinho.Remove(item);
        AtualizarTotais();
    }

    private void AumentarQtd(ItemCarrinho? item)
    {
        if (item == null) return;
        item.Quantidade++;
        AtualizarTotais();
    }

    private void DiminuirQtd(ItemCarrinho? item)
    {
        if (item == null) return;
        if (item.Quantidade > 1)
            item.Quantidade--;
        else
            Carrinho.Remove(item);
        AtualizarTotais();
    }

    private void LimparCarrinho()
    {
        if (MessageBox.Show("Deseja limpar o carrinho?", "Confirmar",
            MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        {
            Carrinho.Clear();
            DescontoVenda = 0;
            AtualizarTotais();
            StatusMessage = "Carrinho limpo";
        }
    }

    private void AbrirPagamento()
    {
        SolicitarPagamento?.Invoke(this);
    }

    public async Task FinalizarVendaAsync(FormaPagamento forma, decimal valorPago)
    {
        IsLoading = true;
        StatusMessage = "Processando pagamento...";
        try
        {
            var venda = await _vendaService.FinalizarVendaAsync(
                Carrinho.ToList(), forma, valorPago, DescontoVenda);

            Carrinho.Clear();
            DescontoVenda = 0;
            AtualizarTotais();
            StatusMessage = $"✅ Venda {venda.NumeroVenda} finalizada! Troco: {venda.Troco:C2}";
        }
        catch (Exception ex)
        {
            StatusMessage = $"❌ Erro: {ex.Message}";
            MessageBox.Show($"Erro ao finalizar venda: {ex.Message}", "Erro",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsLoading = false;
        }
    }

    private void AtualizarTotais()
    {
        OnPropertyChanged(nameof(Subtotal));
        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(TotalItens));
        OnPropertyChanged(nameof(TotalFormatado));
        OnPropertyChanged(nameof(SubtotalFormatado));
        OnPropertyChanged(nameof(CarrinhoVazio));
    }
}

public class RelayCommand<T> : ICommand
{
    private readonly Action<T?> _execute;
    private readonly Func<T?, bool>? _canExecute;

    public RelayCommand(Action<T?> execute, Func<T?, bool>? canExecute = null)
    {
        _execute = execute;
        _canExecute = canExecute;
    }

    public event EventHandler? CanExecuteChanged
    {
        add => CommandManager.RequerySuggested += value;
        remove => CommandManager.RequerySuggested -= value;
    }

    public bool CanExecute(object? parameter) => _canExecute?.Invoke(parameter is T t ? t : default) ?? true;
    public void Execute(object? parameter) => _execute(parameter is T t ? t : default);
}
