using System.Windows.Input;

namespace SimuladorPOS.ViewModels;

public class MainViewModel : BaseViewModel
{
    private object? _abaAtual;
    private string _operador = "Operador 01";
    private string _horaAtual = DateTime.Now.ToString("HH:mm");

    public PDVViewModel PDV { get; } = new();
    public RelatorioViewModel Relatorio { get; } = new();

    public object? AbaAtual
    {
        get => _abaAtual;
        set => SetProperty(ref _abaAtual, value);
    }

    public string Operador
    {
        get => _operador;
        set => SetProperty(ref _operador, value);
    }

    public string HoraAtual
    {
        get => _horaAtual;
        set => SetProperty(ref _horaAtual, value);
    }

    public string DataAtual => DateTime.Now.ToString("dd/MM/yyyy");

    public ICommand IrParaPDVCommand { get; }
    public ICommand IrParaRelatorioCommand { get; }

    public MainViewModel()
    {
        AbaAtual = PDV;
        IrParaPDVCommand = new RelayCommand(() => AbaAtual = PDV);
        IrParaRelatorioCommand = new RelayCommand(AbrirRelatorio);

        var timer = new System.Timers.Timer(1000);
        timer.Elapsed += (_, _) => HoraAtual = DateTime.Now.ToString("HH:mm:ss");
        timer.Start();
    }

    private void AbrirRelatorio()
    {
        _ = Relatorio.CarregarDadosAsync();
        AbaAtual = Relatorio;
    }
}
