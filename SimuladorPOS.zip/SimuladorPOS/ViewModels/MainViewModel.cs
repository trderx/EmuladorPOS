using QRCoder;
using SimuladorPOS.Models;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace SimuladorPOS.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private PaymentScreen _currentScreen = PaymentScreen.Amount;
        private string _amountDisplay = "0,00";
        private PaymentMethod _selectedMethod = PaymentMethod.Pix;
        private Card? _selectedCard;
        private BitmapImage? _qrCodeImage;
        private string _slipText = string.Empty;
        private int _selectedInstallments = 1;
        public PaymentScreen CurrentScreen
        {
            get => _currentScreen;
            set => Set(ref _currentScreen, value);
        }

        public string AmountDisplay
        {
            get => _amountDisplay;
            set => Set(ref _amountDisplay, value);
        }

        public PaymentMethod SelectedMethod
        {
            get => _selectedMethod;
            set
            {
                if (Set(ref _selectedMethod, value))
                {
                    SelectedCard = null;
                    OnPropertyChanged(nameof(AvailableCards));
                    OnPropertyChanged(nameof(ShowInstallments));
                }
            }
        }

        public Card? SelectedCard
        {
            get => _selectedCard;
            set
            {
                if (Set(ref _selectedCard, value))
                    OnPropertyChanged(nameof(HasSelectedCard));
            }
        }

        public bool HasSelectedCard => _selectedCard != null;

        public BitmapImage? QrCodeImage
        {
            get => _qrCodeImage;
            set => Set(ref _qrCodeImage, value);
        }

        public string SlipText
        {
            get => _slipText;
            set => Set(ref _slipText, value);
        }

        public int SelectedInstallments
        {
            get => _selectedInstallments;
            set => Set(ref _selectedInstallments, value);
        }

        public bool ShowInstallments => SelectedMethod == PaymentMethod.Credit;

        public List<Card> AvailableCards => SelectedMethod == PaymentMethod.Debit
            ? HardcodedData.DebitCards
            : HardcodedData.CreditCards;

        public List<int> InstallmentOptions => Enumerable.Range(1, 12).ToList();

        private decimal ParsedAmount
        {
            get
            {
                var raw = AmountDisplay.Replace(".", "").Replace(",", ".");
                return decimal.TryParse(raw, System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out var val) ? val : 0m;
            }
        }

        public ICommand DigitCommand { get; }
        public ICommand BackspaceCommand { get; }
        public ICommand ClearCommand { get; }
        public ICommand SelectMethodCommand { get; }
        public ICommand ProceedToPaymentCommand { get; }
        public ICommand ConfirmPaymentCommand { get; }
        public ICommand NewTransactionCommand { get; }

        public MainViewModel()
        {
            DigitCommand = new RelayCommand(OnDigit);
            BackspaceCommand = new RelayCommand(OnBackspace);
            ClearCommand = new RelayCommand(() => AmountDisplay = "0,00");
            SelectMethodCommand = new RelayCommand(OnSelectMethod);
            ProceedToPaymentCommand = new RelayCommand(OnProceedToPayment, CanProceed);
            ConfirmPaymentCommand = new RelayCommand(OnConfirmPayment, CanConfirm);
            NewTransactionCommand = new RelayCommand(() =>
            {
                AmountDisplay = "0,00";
                SelectedMethod = PaymentMethod.Pix;
                SelectedCard = null;
                SelectedInstallments = 1;
                CurrentScreen = PaymentScreen.Amount;
            });
        }

        private void OnDigit(object? param)
        {
            if (param is not string digit) return;

            var digits = AmountDisplay.Replace(".", "").Replace(",", "");
            if (digits == "000") digits = "0";

            digits += digit;
            if (digits.Length > 10) return;

            var value = long.Parse(digits);
            AmountDisplay = (value / 100m).ToString("N2", new System.Globalization.CultureInfo("pt-BR"));
        }

        private void OnBackspace()
        {
            var digits = AmountDisplay.Replace(".", "").Replace(",", "");
            if (digits.Length <= 1) { AmountDisplay = "0,00"; return; }
            digits = digits[..^1];
            var value = long.Parse(digits);
            AmountDisplay = (value / 100m).ToString("N2", new System.Globalization.CultureInfo("pt-BR"));
        }

        private void OnSelectMethod(object? param)
        {
            if (param is string method && Enum.TryParse<PaymentMethod>(method, out var parsed))
                SelectedMethod = parsed;
        }

        private bool CanProceed() => ParsedAmount > 0;

        private void OnProceedToPayment()
        {
            if (SelectedMethod == PaymentMethod.Pix)
            {
                GenerateQrCode();
                CurrentScreen = PaymentScreen.PixQrCode;
            }
            else
            {
                CurrentScreen = PaymentScreen.CardSelection;
            }
        }

        private bool CanConfirm() => SelectedMethod == PaymentMethod.Pix || SelectedCard != null;

        private async void OnConfirmPayment()
        {
            CurrentScreen = PaymentScreen.Processing;
            await Task.Delay(2500);
            BuildSlip();
            CurrentScreen = PaymentScreen.Slip;
        }

        private void GenerateQrCode()
        {
            using var qrGenerator = new QRCodeGenerator();
            var qrData = qrGenerator.CreateQrCode(HardcodedData.PixQrCodePayload, QRCodeGenerator.ECCLevel.M);
            using var qrCode = new PngByteQRCode(qrData);
            var pngBytes = qrCode.GetGraphic(10);

            using var ms = new System.IO.MemoryStream(pngBytes);
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.StreamSource = ms;
            bmp.EndInit();
            bmp.Freeze();
            QrCodeImage = bmp;
        }

        private void BuildSlip()
        {
            var now = DateTime.Now;
            var nsu = now.ToString("yyMMddHHmmss");
            var auth = new Random().Next(100000, 999999).ToString();

            string methodStr = SelectedMethod switch
            {
                PaymentMethod.Pix => "PIX",
                PaymentMethod.Debit => "DÉBITO",
                PaymentMethod.Credit => "CRÉDITO",
                _ => "DESCONHECIDO"
            };

            string cardInfo = SelectedCard != null
                ? $"CARTÃO: {SelectedCard.Brand} •••• {SelectedCard.MaskedNumber[^4..]}\n" +
                  $"PORTADOR: {SelectedCard.HolderName}\n" +
                  (SelectedInstallments > 1 ? $"PARCELAS: {SelectedInstallments}x\n" : "")
                : "";

            SlipText = HardcodedData.ReceiptSlip
                .Replace("{DATETIME}", now.ToString("dd/MM/yyyy HH:mm:ss"))
                .Replace("{NSU}", nsu)
                .Replace("{AUTH}", auth)
                .Replace("{METHOD}", methodStr)
                .Replace("{CARD_INFO}", string.IsNullOrEmpty(cardInfo) ? "" : cardInfo)
                .Replace("{AMOUNT}", ParsedAmount.ToString("N2", new System.Globalization.CultureInfo("pt-BR")));
        }
    }
}
