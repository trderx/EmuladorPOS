using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using SimuladorPOS.Models;
using SimuladorPOS.Services;

namespace SimuladorPOS.ViewModels;

public class RelatorioViewModel : BaseViewModel
{
    private readonly VendaService _vendaService;
    private DateTime _dataInicio = DateTime.Today;
    private DateTime _dataFim = DateTime.Today;
    private bool _isLoading;
    private ResumoVendas? _resumo;
    private Venda? _vendaSelecionada;

    public DateTime DataInicio
    {
        get => _dataInicio;
        set => SetProperty(ref _dataInicio, value);
    }

    public DateTime DataFim
    {
        get => _dataFim;
        set => SetProperty(ref _dataFim, value);
    }

    public bool IsLoading
    {
        get => _isLoading;
        set => SetProperty(ref _isLoading, value);
    }

    public ResumoVendas? Resumo
    {
        get => _resumo;
        set => SetProperty(ref _resumo, value);
    }

    public Venda? VendaSelecionada
    {
        get => _vendaSelecionada;
        set => SetProperty(ref _vendaSelecionada, value);
    }

    public ObservableCollection<Venda> Vendas { get; } = new();

    public ICommand FiltrarCommand { get; }
    public ICommand HojeCommand { get; }
    public ICommand SemanaCommand { get; }
    public ICommand MesCommand { get; }

    public RelatorioViewModel()
    {
        _vendaService = new VendaService(new ProdutoService());
        FiltrarCommand = new AsyncRelayCommand(CarregarDadosAsync);
        HojeCommand = new AsyncRelayCommand(FiltrarHoje);
        SemanaCommand = new AsyncRelayCommand(FiltrarSemana);
        MesCommand = new AsyncRelayCommand(FiltrarMes);
        _ = CarregarDadosAsync();
    }

    private async Task FiltrarHoje()
    {
        DataInicio = DateTime.Today;
        DataFim = DateTime.Today;
        await CarregarDadosAsync();
    }

    private async Task FiltrarSemana()
    {
        DataInicio = DateTime.Today.AddDays(-7);
        DataFim = DateTime.Today;
        await CarregarDadosAsync();
    }

    private async Task FiltrarMes()
    {
        DataInicio = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        DataFim = DateTime.Today;
        await CarregarDadosAsync();
    }

    public async Task CarregarDadosAsync()
    {
        IsLoading = true;
        try
        {
            var vendas = await _vendaService.ObterHistoricoAsync(DataInicio, DataFim);
            var resumo = await _vendaService.ObterResumoAsync(DataInicio, DataFim);

            Application.Current.Dispatcher.Invoke(() =>
            {
                Vendas.Clear();
                foreach (var v in vendas)
                    Vendas.Add(v);
                Resumo = resumo;
            });
        }
        finally
        {
            IsLoading = false;
        }
    }
}
