using Microsoft.EntityFrameworkCore;
using SimuladorPOS.Data;
using SimuladorPOS.Models;

namespace SimuladorPOS.Services;

public class ProdutoService
{
    public async Task<List<Produto>> ObterTodosAsync(string? filtro = null, string? categoria = null)
    {
        using var db = new AppDbContext();
        var query = db.Produtos.Where(p => p.Ativo).AsQueryable();

        if (!string.IsNullOrWhiteSpace(filtro))
            query = query.Where(p =>
                p.Nome.Contains(filtro) ||
                p.Codigo.Contains(filtro) ||
                p.Descricao.Contains(filtro));

        if (!string.IsNullOrWhiteSpace(categoria))
            query = query.Where(p => p.Categoria == categoria);

        return await query.OrderBy(p => p.Categoria).ThenBy(p => p.Nome).ToListAsync();
    }

    public async Task<List<string>> ObterCategoriasAsync()
    {
        using var db = new AppDbContext();
        return await db.Produtos
            .Where(p => p.Ativo)
            .Select(p => p.Categoria)
            .Distinct()
            .OrderBy(c => c)
            .ToListAsync();
    }

    public async Task<Produto?> BuscarPorCodigoAsync(string codigo)
    {
        using var db = new AppDbContext();
        return await db.Produtos.FirstOrDefaultAsync(p => p.Codigo == codigo && p.Ativo);
    }

    public async Task SalvarAsync(Produto produto)
    {
        using var db = new AppDbContext();
        if (produto.Id == 0)
            db.Produtos.Add(produto);
        else
            db.Produtos.Update(produto);
        await db.SaveChangesAsync();
    }

    public async Task AtualizarEstoqueAsync(int produtoId, int quantidade)
    {
        using var db = new AppDbContext();
        var produto = await db.Produtos.FindAsync(produtoId);
        if (produto != null)
        {
            produto.Estoque -= quantidade;
            await db.SaveChangesAsync();
        }
    }
}
