using Microsoft.EntityFrameworkCore;
using SimuladorPOS.Data;
using SimuladorPOS.Models;

namespace SimuladorPOS.Services;

public class VendaService
{
    private readonly ProdutoService _produtoService;

    public VendaService(ProdutoService produtoService)
    {
        _produtoService = produtoService;
    }

    public async Task<Venda> FinalizarVendaAsync(
        List<ItemCarrinho> itens,
        FormaPagamento formaPagamento,
        decimal valorPago,
        decimal desconto = 0,
        string? operador = null)
    {
        var subtotal = itens.Sum(i => i.Subtotal);
        var total = subtotal - desconto;
        var troco = formaPagamento == FormaPagamento.Dinheiro ? Math.Max(0, valorPago - total) : 0;

        var venda = new Venda
        {
            NumeroVenda = GerarNumeroVenda(),
            DataHora = DateTime.Now,
            Status = StatusVenda.Finalizada,
            FormaPagamento = formaPagamento,
            Subtotal = subtotal,
            Desconto = desconto,
            Total = total,
            ValorPago = valorPago,
            Troco = troco,
            NomeOperador = operador ?? "Operador Padrão",
            Itens = itens.Select(i => new ItemVenda
            {
                ProdutoId = i.Produto.Id,
                NomeProduto = i.Produto.Nome,
                PrecoUnitario = i.PrecoUnitario,
                Quantidade = i.Quantidade,
                Desconto = i.Desconto
            }).ToList()
        };

        using var db = new AppDbContext();
        db.Vendas.Add(venda);
        await db.SaveChangesAsync();

        foreach (var item in itens)
            await _produtoService.AtualizarEstoqueAsync(item.Produto.Id, item.Quantidade);

        return venda;
    }

    public async Task<List<Venda>> ObterHistoricoAsync(DateTime? de = null, DateTime? ate = null)
    {
        using var db = new AppDbContext();
        var query = db.Vendas
            .Include(v => v.Itens)
            .Where(v => v.Status == StatusVenda.Finalizada)
            .AsQueryable();

        if (de.HasValue)
            query = query.Where(v => v.DataHora >= de.Value);
        if (ate.HasValue)
            query = query.Where(v => v.DataHora <= ate.Value.AddDays(1));

        return await query.OrderByDescending(v => v.DataHora).ToListAsync();
    }

    public async Task<ResumoVendas> ObterResumoAsync(DateTime? de = null, DateTime? ate = null)
    {
        var vendas = await ObterHistoricoAsync(de, ate);
        return new ResumoVendas
        {
            TotalVendas = vendas.Count,
            TotalArrecadado = vendas.Sum(v => v.Total),
            TicketMedio = vendas.Count > 0 ? vendas.Average(v => v.Total) : 0,
            VendasDinheiro = vendas.Count(v => v.FormaPagamento == FormaPagamento.Dinheiro),
            VendasCartao = vendas.Count(v => v.FormaPagamento == FormaPagamento.CartaoCredito || v.FormaPagamento == FormaPagamento.CartaoDebito),
            VendasPIX = vendas.Count(v => v.FormaPagamento == FormaPagamento.PIX),
        };
    }

    private static string GerarNumeroVenda()
    {
        return $"PDV-{DateTime.Now:yyyyMMdd}-{Random.Shared.Next(1000, 9999)}";
    }
}

public class ResumoVendas
{
    public int TotalVendas { get; set; }
    public decimal TotalArrecadado { get; set; }
    public decimal TicketMedio { get; set; }
    public int VendasDinheiro { get; set; }
    public int VendasCartao { get; set; }
    public int VendasPIX { get; set; }
}
