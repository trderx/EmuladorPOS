using System.Windows;
using Microsoft.EntityFrameworkCore;
using SimuladorPOS.Data;

namespace SimuladorPOS;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        InicializarBancoDeDados();
    }

    private static void InicializarBancoDeDados()
    {
        try
        {
            using var db = new AppDbContext();
            db.Database.EnsureCreated();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Erro ao inicializar banco de dados:\n{ex.Message}",
                "Erro de Inicialização", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
