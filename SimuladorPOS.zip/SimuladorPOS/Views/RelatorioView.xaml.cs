using System.Windows.Controls;

namespace SimuladorPOS.Views;

public partial class RelatorioView : UserControl
{
    public RelatorioView()
    {
        InitializeComponent();
    }
}
