using System.Windows;
using SimuladorPOS.ViewModels;

namespace SimuladorPOS.Views;

public partial class PagamentoWindow : Window
{
    public PagamentoWindow(PagamentoViewModel vm)
    {
        InitializeComponent();
        DataContext = vm;
        vm.Confirmar += () => { DialogResult = true; Close(); };
        vm.Cancelar += () => { DialogResult = false; Close(); };
    }
}
