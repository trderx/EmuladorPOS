using System.Windows.Controls;
using SimuladorPOS.ViewModels;

namespace SimuladorPOS.Views;

public partial class PDVView : UserControl
{
    public PDVView()
    {
        InitializeComponent();
        DataContextChanged += OnDataContextChanged;
    }

    private void OnDataContextChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
    {
        if (e.NewValue is PDVViewModel vm)
        {
            vm.SolicitarPagamento += AbrirPagamento;
        }
        if (e.OldValue is PDVViewModel oldVm)
        {
            oldVm.SolicitarPagamento -= AbrirPagamento;
        }
    }

    private async void AbrirPagamento(PDVViewModel vm)
    {
        var pagamentoVm = new PagamentoViewModel(vm.Total, vm.DescontoVenda);
        var window = new PagamentoWindow(pagamentoVm);
        window.Owner = System.Windows.Application.Current.MainWindow;

        if (window.ShowDialog() == true && pagamentoVm.Confirmado)
        {
            await vm.FinalizarVendaAsync(pagamentoVm.FormaSelecionada, pagamentoVm.ValorPago);
        }
    }
}
