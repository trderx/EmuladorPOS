using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using SimuladorPOS.Models;

namespace SimuladorPOS.Helpers;

public class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        bool b = value is bool bv && bv;
        if (parameter?.ToString() == "Inverse") b = !b;
        return b ? Visibility.Visible : Visibility.Collapsed;
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => value is Visibility v && v == Visibility.Visible;
}

public class FormaPagamentoConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is FormaPagamento forma)
            return forma switch
            {
                FormaPagamento.Dinheiro => "💵 Dinheiro",
                FormaPagamento.CartaoCredito => "💳 Crédito",
                FormaPagamento.CartaoDebito => "💳 Débito",
                FormaPagamento.PIX => "⚡ PIX",
                FormaPagamento.Voucher => "🎟 Voucher",
                _ => forma.ToString()
            };
        return value?.ToString() ?? string.Empty;
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}

public class StatusVendaConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is StatusVenda status)
            return status switch
            {
                StatusVenda.Finalizada => "✅ Finalizada",
                StatusVenda.Cancelada => "❌ Cancelada",
                StatusVenda.Aberta => "🔄 Aberta",
                _ => status.ToString()
            };
        return value?.ToString() ?? string.Empty;
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}

public class DecimalToCurrencyConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is decimal d) return d.ToString("C2", new CultureInfo("pt-BR"));
        return value?.ToString() ?? "R$ 0,00";
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}

public class FormaPagamentoColorConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is FormaPagamento forma && parameter is string expected)
        {
            bool match = forma.ToString() == expected;
            return match
                ? new SolidColorBrush(Color.FromRgb(0, 180, 120))
                : new SolidColorBrush(Color.FromRgb(50, 55, 65));
        }
        return new SolidColorBrush(Color.FromRgb(50, 55, 65));
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}

public class EqualsToBoolConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => Equals(value?.ToString(), parameter?.ToString());
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}
